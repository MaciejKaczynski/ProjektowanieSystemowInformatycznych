﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Adapterhotel
{
    class Adaptee
    {
        public string GetRequest()
        {
            return "Podsumowanie: ";
        }
    }
}
