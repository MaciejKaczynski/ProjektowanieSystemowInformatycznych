﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Adapterhotel
{

    class Adapter : ITarget
    {
        private readonly Adaptee _adaptee;

        public Adapter(Adaptee adaptee)
        {
            this._adaptee = adaptee;
        }

        public string GetZapytanie(int cena, int liczba_osob)
        {
            return $"{this._adaptee.GetRequest()} Wynajęto pokój! Liczba osób zakwaterowanych: " + liczba_osob + ". Koszt pobytu za noc: " + cena ;
        }
    }
}
