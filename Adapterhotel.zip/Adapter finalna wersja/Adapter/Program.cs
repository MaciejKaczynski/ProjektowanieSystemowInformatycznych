﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Adapterhotel
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Podaj liczbę osób wynajmującą pokój:");
            int liczba_osob = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Wybierz interesującą Cię cenę za noc:");
            Console.WriteLine("-> 50zł");
            Console.WriteLine("-> 100zł");
            Console.WriteLine("-> 200zł");
            int cena = Convert.ToInt32(Console.ReadLine());
            if(cena==50)
            {
                Console.WriteLine("Wybrano pokój studencki.");
                Console.ReadKey();
            }
            else if(cena==100)
            {
                Console.WriteLine("Wybrano pokój normalny z dostępem do łazienki i brakiem balkonu.");
                Console.ReadKey();
            }
            else if(cena==200)
            {
                Console.WriteLine("Wybrano pokój premium z dostępem do łazienki i balkonem.");
                Console.ReadKey();
            }
            else
            {
                Console.WriteLine("Nie ma pokoju istniejącego w wybranej cenie");
                Console.ReadKey();
                Environment.Exit(0);
            }
            Adaptee adaptee = new Adaptee();
            ITarget target = new Adapter(adaptee);
            Console.WriteLine(target.GetZapytanie(cena, liczba_osob));
            Console.ReadKey();
        }
    }
}
