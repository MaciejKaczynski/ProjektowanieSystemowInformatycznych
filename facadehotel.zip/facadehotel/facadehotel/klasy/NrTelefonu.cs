﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace facadehotel.klasy
{
    class NrTelefonu
    {
        public void SetNrTelefonu(int nrtelefonu)
        {
            Console.WriteLine(" Numer telefonu rezerwującego to: "+nrtelefonu);
        }

    }

}
