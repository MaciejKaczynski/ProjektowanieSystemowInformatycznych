﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace facadehotel.klasy
{
    class Nazwisko
    {
        
        public void SetNazwisko(string nazwisko)
        {
            Console.WriteLine(" Nazwisko rezerwującego to: "+nazwisko);
        }

    }
}

