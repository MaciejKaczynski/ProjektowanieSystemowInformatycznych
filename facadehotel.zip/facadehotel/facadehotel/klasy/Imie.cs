﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace facadehotel.klasy
{
    class Imie
    {
        public void SetImie(string imie)
        {
            Console.WriteLine(" Imię rezerwującego to: "+imie);
        }

    }
    
}
