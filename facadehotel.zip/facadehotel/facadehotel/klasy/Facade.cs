﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace facadehotel.klasy
{
    class Facade
    {
        Imie Imie;
        Nazwisko Nazwisko;
        Adres Adres;
        NrTelefonu NrTelefonu;

        public Facade()
        {
            Imie = new Imie();
            Nazwisko = new Nazwisko();
            Adres = new Adres();
            NrTelefonu = new NrTelefonu();

        }

        public void rezerwujacy() 
        {

            Console.WriteLine(" Dodawanie nowego rezerwującego \n");
            Console.WriteLine(" Wprowadź Imię ");
            string imie = Convert.ToString(Console.ReadLine());
            Imie.SetImie(imie);
            Console.WriteLine(" Wprowadź nazwisko ");
            string nazwisko = Convert.ToString(Console.ReadLine());
            Nazwisko.SetNazwisko(nazwisko);
            Console.WriteLine(" Wprowadź adres ");
            string adres = Convert.ToString(Console.ReadLine());
            Adres.SetAdres(adres);
            Console.WriteLine(" Wprowadż numer telefonu ");
            int nrtelefonu = Convert.ToInt32(Console.ReadLine());
            NrTelefonu.SetNrTelefonu(nrtelefonu);
            



            Console.WriteLine("\n Gratulacje! Nowy rezerwujący dodany ");
        }




    }

}
