﻿using System;
using facadehotel.klasy;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace facadehotel
{
    class Program
    {
        static void Main(string[] args)
        {
            Facade facade = new Facade();

            facade.rezerwujacy();
            Console.ReadKey();
        }




    }
}