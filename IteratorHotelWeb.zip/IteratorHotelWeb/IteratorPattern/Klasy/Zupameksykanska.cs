﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IteratorHotelWeb.Klasy
{
    class Zupameksykanska : Glowna
    {
        public override void Szczegoly()
        {
            Console.WriteLine("Zupa z mięsem mielonym + bułka, cena: 16 zł");
        }
        public override void Zamowienie()
        {
            Console.WriteLine("Wykonano zamówienie");
            //tutaj zamowienie bedzie zapisywane i wysylane
        }
    }
}
