﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IteratorHotelWeb.Klasy
{
    class Kebab : Glowna
    {
        public override void Szczegoly()
        {
            Console.WriteLine("Cienkie ciasto + mięso(baranina/kurczak/mieszane) + surówki + sos, cena: 13 zł");
        }
        public override void Zamowienie()
        {
            Console.WriteLine("Wykonano zamówienie");
            //tutaj zamowienie bedzie zapisywane i wysylane
        }
    }
}
