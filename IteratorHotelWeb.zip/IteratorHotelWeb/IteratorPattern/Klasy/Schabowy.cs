﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IteratorHotelWeb.Klasy
{
    class Schabowy : Glowna
    {
        public override void Szczegoly() 
        {
            Console.WriteLine("Kotlet schabowy + ziemniaki + ogórek kiszony, cena: 23 zł");
        }
        public override void Zamowienie()
        {
            Console.WriteLine("Wykonano zamówienie");
            //tutaj zamowienie bedzie zapisywane i wysylane
        }
    }
}
