﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IteratorHotelWeb.Klasy
{
    class Rosol : Glowna
    {
        public override void Szczegoly()
        {
            Console.WriteLine("Rosół + makaron, cena: 16 zł");
        }
        public override void Zamowienie()
        {
            Console.WriteLine("Wykonano zamówienie");
            //tutaj zamowienie bedzie zapisywane i wysylane
        }
    }
}
