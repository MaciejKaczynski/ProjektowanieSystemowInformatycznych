﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IteratorHotelWeb.Klasy
{
    class Mielony : Glowna
    {
        public override void Szczegoly()
        {
            Console.WriteLine("Kotlet mielony + ziemniaki + buraki zasmażane, cena: 21 zł");
        }
        public override void Zamowienie()
        {
            Console.WriteLine("Wykonano zamówienie");
            //tutaj zamowienie bedzie zapisywane i wysylane
        }
    }
}
