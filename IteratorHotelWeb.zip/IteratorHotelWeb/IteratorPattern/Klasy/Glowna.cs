﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IteratorHotelWeb.Klasy
{
    abstract class Glowna
    {
        public abstract void Szczegoly();
        public abstract void Zamowienie();

        public void Template()
        {
            Szczegoly();
            Console.WriteLine("Czy chcesz zamówić ten posiłek? (wpisz: tak/nie)");
            String zapytanie = Console.ReadLine();
            if(zapytanie == "tak")
            {
                Zamowienie();
                
            }else
            {

                Console.WriteLine("Nie zamówiono");
            }
            Console.ReadLine();
            Environment.Exit(0);
        }
    }
}
