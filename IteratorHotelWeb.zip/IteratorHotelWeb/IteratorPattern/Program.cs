using IteratorHotelWeb.Klasy;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace IteratorHotelWeb
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Collection collection = new Collection();
            collection[0] = new Item("Schabowy");
            collection[1] = new Item("Mielony");
            collection[2] = new Item("Ros�");
            collection[3] = new Item("Zupa meksyka�ska");
            collection[4] = new Item("Kebab");
            collection[5] = new Item("Nie ma wi�cej da�");

            Iterator iterator = collection.CreateIterator();


            Console.WriteLine("Menu HotelRestauracja:  \n");

            int wpisywana = 0;
            wpisywana = Convert.ToInt32(Console.ReadLine());
            for (Item item = iterator.First();
                !iterator.IsDone; item = iterator.Next())
            {

                
                while (wpisywana == 1)
                {

                    Console.WriteLine(item.Name);
                    wpisywana = 0;
               
                }
                wpisywana = Convert.ToInt32(Console.ReadLine());
                while (wpisywana == 2)
                {
                    Console.WriteLine("Szczeg�y posi�ku: "+item.Name);
                    string nazwa = Convert.ToString(item.Name);
                    Console.WriteLine(nazwa);
                    if (nazwa == "Schabowy")
                    {
                        Glowna schabowy = new Schabowy();
                        schabowy.Template();
                    }
                    if (nazwa == "Mielony")
                    {
                        Glowna mielony = new Mielony();
                        mielony.Template();
                    }
                    if (nazwa == "Ros�")
                    {
                        Glowna rosol = new Rosol();
                        rosol.Template();
                    }
                    if (nazwa == "Zupa meksyka�ska")
                    {
                        Glowna zupameksykanska = new Zupameksykanska();
                        zupameksykanska.Template();
                    }
                    if (nazwa == "Kebab")
                    {
                        Glowna kebab = new Kebab();
                        kebab.Template();
                    }
                    wpisywana = 0;

                }
                
                
                
            }           
        }
    }
}
