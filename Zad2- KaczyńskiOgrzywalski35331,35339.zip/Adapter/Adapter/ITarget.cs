﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Adapterhotel
{
    
    public interface ITarget
    {
        string GetZapytanie();
    }
}
