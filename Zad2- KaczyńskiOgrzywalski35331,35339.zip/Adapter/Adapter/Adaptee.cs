﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Adapterhotel
{
    class Adaptee
    {
        public string GetProsba()
        {
            return "Specyficzne zapytanie";
        }
    }
}
